import './CSS/App.css';
import "./CSS/index.css";
import SurveyComponent from './Components/SurveyComponent';


function App() {
  return (
    <div className="App">

      <SurveyComponent/>

    </div>
  );
}

export default App;